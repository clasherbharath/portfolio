# Bharath K — Portfolio Website

A modern, glassmorphism-styled personal portfolio for Bharath K, B.E. Electronics & Computer Engineering student at Sona College of Technology, Salem.

## 🚀 Features

- **Glassmorphism UI** with dark/light mode toggle
- **Fully responsive** — mobile, tablet, and desktop
- **Animated hero** with typing effect and floating chips
- **Interactive certificate gallery** with modal preview
- **Timeline-based education** section
- **Smooth scroll animations** powered by Intersection Observer
- **Contact form** with mailto integration
- **Resume download** button
- **GitHub & LinkedIn** social links

## 📁 Project Structure

```
bharath-portfolio/
├── index.html              ← Main page (all sections)
├── css/
│   ├── style.css           ← Core styles + glassmorphism
│   └── responsive.css      ← Breakpoints for all screen sizes
├── js/
│   └── script.js           ← Animations, theme, modal, typed effect
└── assets/
    ├── images/
    │   ├── profile.jpg     ← Bharath's profile photo
    │   ├── certificate1.jpg
    │   └── certificate2.jpg
    └── pdf/
        └── Bharath_Resume.pdf
```

## 🌐 Deployment

### GitHub Pages
1. Push this folder to a GitHub repo (e.g. `bharath-portfolio`)
2. Go to **Settings → Pages**
3. Source: `main` branch, root `/`
4. Your site will be live at `https://<username>.github.io/bharath-portfolio`

### Vercel
1. Import the GitHub repo in [vercel.com](https://vercel.com)
2. Framework preset: **Other / Static**
3. Build command: *(leave blank)*
4. Output directory: `.` (root)
5. Deploy — you'll get a `*.vercel.app` URL instantly

## 🔧 Customization

- **Social links**: Update GitHub/LinkedIn URLs in `index.html` (`href` on `.social-btn` elements)
- **Colors**: Edit CSS variables in `:root` inside `css/style.css`
- **Content**: All text content is in `index.html`
- **Add certificates**: Copy a `.cert-card` block and update `data-src`, `data-title`, and the image

## 📦 No Build Required

This is a pure HTML/CSS/JS project. Just open `index.html` in any browser — no npm, no bundlers needed.
